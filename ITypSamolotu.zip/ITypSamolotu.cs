﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plane
{
    internal interface ITypSamolotu
    {
        double Waga { get; set; }
        int IloscSilnikow { get; set; }
        int IloscMiejsc { get; set; }
        string TypUsterzenia { get; set; }
    }
}
