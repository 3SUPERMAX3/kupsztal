﻿using System;

namespace Plane
{
    class Program
    {
        static void Main(string[] args)
        {
            Samolot samolot = new Samolot();
            samolot.Waga = 40000.0;
            samolot.IloscSilnikow = 2;
            samolot.IloscMiejsc = 60;
            samolot.TypUsterzenia = "skrzydlaty fest";

            Console.WriteLine("Dane Samolotu: ");
            Console.WriteLine("Waga: " + samolot.Waga + "kg");
            Console.WriteLine("Ilość silników: " + samolot.IloscSilnikow);
            Console.WriteLine("Ilość miejsc: " + samolot.IloscMiejsc);
            Console.WriteLine("Typ usterzenia: " + samolot.TypUsterzenia);

            Console.ReadKey(); 

        }

    }
}
