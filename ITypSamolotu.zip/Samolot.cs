﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Plane
{
   internal  class Samolot : ITypSamolotu
    {
        private double waga;
        private int iloscSilnikow;
        private int iloscMiejsc;
        private string typUsterzenia;

        public double Waga
        {
            get { return waga; }
            set { waga = value; }
        }
        public int IloscSilnikow
        {
            get { return iloscSilnikow; }
            set { iloscSilnikow = value; }
        }
        public int IloscMiejsc
        {
            get { return iloscMiejsc; }
            set { iloscMiejsc = value; }
        }
        public string TypUsterzenia
        {
            get { return typUsterzenia; }
            set { typUsterzenia = value; }

        }
    }
}
