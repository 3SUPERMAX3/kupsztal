﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praca
{
    public class Ochroniarz : Pracownik
    {
        public override void Pracuj() { Console.WriteLine("ochroniarz pracuje"); }
    }
}
