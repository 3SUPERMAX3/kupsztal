﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Praca
{
    public class Pracownik
    {
        virtual public void Pracuj() { Console.WriteLine("Pracownik pracuje"); }
    }
}
